package com.fuwenjun.projectUtils.jdbc;
/**
 * 可使用的数据库种类
 * @author fuwenjun01
 *
 */
public enum DataBase {
    MYSQL,ORACLE;
    
}
