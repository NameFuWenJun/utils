package com.fuwenjun.projectUtils.jdbc;

public class DatabaseInfoConstants {
	
	public final static String DATATYPE = "dateType";
	
	public final static String DATABASE = "database";
	
	public final static String IPANDPORT = "ipAndPort";
	
	public final static String USERNAME = "username";
	
	public final static String PASSWORD = "password";
	
}
